package com.example.javafx;

import javafx.beans.property.SimpleListProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.Arrays;
import java.util.List;

public class Profile {
    private final SimpleStringProperty name;
    private final SimpleStringProperty status;
    private final SimpleStringProperty image;
    private final SimpleListProperty<String> friends; // Change to SimpleListProperty
    private final SimpleStringProperty quote;

    public Profile(String name, String status, String quote, String image, List<String> friends) {
        this.name = new SimpleStringProperty(name);
        this.status = new SimpleStringProperty(status);
        this.quote = new SimpleStringProperty(quote);
        this.image = new SimpleStringProperty(image);
        this.friends = new SimpleListProperty<>(FXCollections.observableArrayList(friends));
    }

    // New constructor to create a profile from a string with correct friend separation
    public Profile(String profileString) {
        String[] parts = profileString.split(",");
        this.name = new SimpleStringProperty(parts[0]);
        this.status = new SimpleStringProperty(parts[1]);
        this.quote = new SimpleStringProperty(parts[2]);
        this.image = new SimpleStringProperty(parts[3]);

        // Initialize the friends list by converting the array to a list
        this.friends = new SimpleListProperty<>(FXCollections.observableArrayList(Arrays.asList(parts).subList(4, parts.length)));
    }

    // Method to convert a profile to a string without descriptions and without square brackets around friends
    @Override
    public String toString() {
        // Remove square brackets from friends
        String friendsString = friends.get().toString().replaceAll("\\[|\\]", "");

        return String.join(",", name.get(), status.get(), quote.get(), image.get(), friendsString);
    }

    public String getName() {
        return this.name.get();
    }

    public String getStatus() {
        return this.status.get();
    }

    public void setStatus(String status) {
        this.status.set(status);
    }

    public String getImageURL() {
        return this.image.get();
    }

    public void setImageURL(String imageURL) {
        this.image.set(imageURL);
    }

    public ObservableList<String> getFriends() {
        return this.friends.get();
    }

    public String getFavoriteQuote() {
        return this.quote.get();
    }

    public void setFavoriteQuote(String favoriteQuote) {
        this.quote.set(favoriteQuote);
    }
}
