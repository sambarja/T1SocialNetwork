package com.example.javafx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.HashMap;




public class Controller {

    @FXML
    public TextField nameField;
    public Label name;
    public Label statusLabel;
    public Label currentStatus;
    public TextField statusChangeLabel;
    public TextField pictureLabel;
    public TextField friendLabel;
    public TextField unfriendLabel;
    public TextField quoteLabel;
    public Label favoriteQuote;
    public ImageView pictureView;
    public ListView<String> listView;

    private Graph graph;
    private Profile currentProfile;
    public static final String PROFILES_FILE_PATH = "profiles.txt";


    private void saveProfilesToFile() {
        // Save profiles to the file when adding or updating
        graph.saveProfilesToFile(PROFILES_FILE_PATH);
    }

    @FXML
    private void initialize() {
        this.graph = new Graph();
        this.currentProfile = null;

        // Create the file if it doesn't exist
        File file = new File(PROFILES_FILE_PATH);
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        // Load existing profiles from the file
        graph.loadProfilesFromFile(PROFILES_FILE_PATH);
        if (!graph.getProfiles().isEmpty()) {
            Map.Entry<String, Profile> entry = graph.getProfiles().entrySet().iterator().next();
            this.currentProfile = entry.getValue();
            displayProfile(this.currentProfile);
        }

    }


    private void clearProfile() {
        this.nameField.clear();
        this.statusChangeLabel.clear();
        this.pictureLabel.clear();
        this.friendLabel.clear();
        this.unfriendLabel.clear();
        this.quoteLabel.clear();
        this.pictureView.setImage(null);
        this.listView.getItems().clear();
        this.currentStatus.setText("");
        this.favoriteQuote.setText("");
        this.name.setText("");
        this.currentProfile = null;
    }

    private void displayProfile(Profile profile) {
        this.name.setText(" " + profile.getName());
        this.currentStatus.setText("Status: " + profile.getStatus());
        this.favoriteQuote.setText("Favorite Quote: " + profile.getFavoriteQuote());



        ObservableList<String> friendsList = FXCollections.observableArrayList();

        // Update the ListView with the friends of the displayed profile
        for (String friend : profile.getFriends()) {
            friendsList.add(friend);
        }

        this.listView.setItems(friendsList);


        String imageUrl = profile.getImageURL();
        if (imageUrl != null && !imageUrl.trim().isEmpty()) {
            try {
                Image image = new Image(imageUrl);
                this.pictureView.setImage(image);
            } catch (IllegalArgumentException e) {
                System.err.println("Error loading image: " + e.getMessage());
                this.pictureView.setImage(null);
            }
        } else {
            this.pictureView.setImage(null);
        }
    }

    public void handleAdd(ActionEvent actionEvent) {
        if (!this.nameField.getText().trim().isEmpty()) {
            String name = this.nameField.getText();
            Profile existingProfile = findProfileByName(name);

            if (existingProfile == null) {
                // Create a new profile
                Profile profile = new Profile(name, "", "", "", new ArrayList<String>());

                profile.setStatus(this.statusChangeLabel.getText());
                profile.setFavoriteQuote(this.quoteLabel.getText());
                this.statusLabel.setText(name + " added");

                // No need to add friends here, as it will be updated later

                String imageUrl = this.pictureLabel.getText();
                if (!imageUrl.trim().isEmpty()) {
                    profile.setImageURL(imageUrl);
                    this.pictureView.setImage(new Image(imageUrl));
                } else {
                    profile.setImageURL("unknown.png");
                    this.pictureView.setImage(new Image("unknown.png"));
                }

                // Add the profile to the social graph
                graph.addProfile(profile);
                saveProfilesToFile();

                // Update the friends in the social graph
                for (String friend : profile.getFriends()) {
                    Profile friendProfile = findProfileByName(friend);
                    if (friendProfile != null) {
                        graph.addFriendship(profile, friendProfile);
                    }
                }

                // Update the UI

                this.displayProfile(profile);
                this.currentProfile = profile;

            } else {
                // Reset previous profile status and quote
                existingProfile.setStatus(this.statusChangeLabel.getText());
                existingProfile.setFavoriteQuote(this.quoteLabel.getText());

                // Update the UI for the existing profile
                this.displayProfile(existingProfile);
                this.currentProfile = existingProfile;

                this.statusLabel.setText("Profile Updated");
            }
        }
    }


    public void handleDelete(ActionEvent actionEvent) {
        if (this.currentProfile != null) {
            this.graph.removeProfile(this.currentProfile);
            this.statusLabel.setText(this.currentProfile.getName() + " deleted");
            this.clearProfile(); // Reset text fields
        } else {
            this.statusLabel.setText("No profile selected");
        }
    }

    private Profile findProfileByName(String name) {
        for (Map.Entry<String, Profile> entry : this.graph.getProfiles().entrySet()) {
            if (entry.getValue().getName().equalsIgnoreCase(name)) {
                return entry.getValue();
            }
        }
        return null;
    }

    public void handleSearch(ActionEvent actionEvent) {
        if (!this.nameField.getText().trim().isEmpty()) {
            String name = this.nameField.getText();
            Profile profile = this.findProfileByName(name);
            this.clearProfile(); // Reset text fields
            if (profile != null) {
                this.statusLabel.setText(name + " searched");
                this.displayProfile(profile);
                this.currentProfile = profile;
            } else {
                this.statusLabel.setText("Profile not found");
            }
        }
    }

    public void handleStatus(ActionEvent actionEvent) {
        if (!statusChangeLabel.getText().trim().isEmpty() && !this.nameField.getText().trim().isEmpty()) {
            String name = this.nameField.getText();
            Profile profile = this.findProfileByName(name);
            if (profile != null) {
                profile.setStatus(this.statusChangeLabel.getText());
                statusLabel.setText("status changed to " + statusChangeLabel.getText());
                currentStatus.setText("" + statusChangeLabel.getText());
                this.statusChangeLabel.clear();
            }
        }
    }

    public void handlePicture(ActionEvent actionEvent) {
        if (!pictureLabel.getText().trim().isEmpty() && !this.nameField.getText().trim().isEmpty()) {
            String name = this.nameField.getText();
            Profile profile = this.findProfileByName(name);
            String imageUrl = this.pictureLabel.getText();

            try {
                this.pictureView.setImage(new Image(imageUrl));
                profile.setImageURL(imageUrl);
                statusLabel.setText("picture changed to " + pictureLabel.getText());
            } catch (IllegalArgumentException e) {
                statusLabel.setText("Image '" + pictureLabel.getText() + "' not found");
            }
            this.pictureLabel.clear();
        }
    }

    public void handleAddFriend(ActionEvent actionEvent) {
        if (!friendLabel.getText().trim().isEmpty()) {
            String name = friendLabel.getText();
            Profile profile = findProfileByName(name);

            if (profile != null) {
                profile.getFriends().add(currentProfile.getName());
                currentProfile.getFriends().add(name);
                statusLabel.setText(name + " added as a friend");

                // Update the social graph
                graph.addFriendship(currentProfile, profile);
                saveProfilesToFile();

                // Update the UI
                this.displayProfile(this.currentProfile);
                this.friendLabel.clear();
            } else {
                this.statusLabel.setText("Profile not found");
            }
        }
    }



    public void handleUnfriend(ActionEvent actionEvent) {
        if (currentProfile != null && !unfriendLabel.getText().trim().isEmpty()) {
            String name = unfriendLabel.getText();
            Profile friendProfile = findProfileByName(name);

            if (friendProfile != null) {
                currentProfile.getFriends().remove(name);
                friendProfile.getFriends().remove(currentProfile.getName());
                statusLabel.setText(name + " removed as a friend");

                // Update the social graph
                graph.removeFriendship(currentProfile, friendProfile);

                // Update the UI
                displayProfile(currentProfile);
            } else {
                statusLabel.setText("Profile not found");
            }
        }
    }


    public void handleQuote(ActionEvent actionEvent) {
        if (!quoteLabel.getText().trim().isEmpty()) {
            String name = this.nameField.getText();
            Profile profile = this.findProfileByName(name);
            if (profile != null) {
                profile.setFavoriteQuote(this.quoteLabel.getText());
                statusLabel.setText("Quote changed to " + quoteLabel.getText());
                favoriteQuote.setText("" + quoteLabel.getText());
                this.quoteLabel.clear();
            }
        }
    }
}
