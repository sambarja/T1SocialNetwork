package com.example.javafx;

import java.io.*;
import java.util.*;

// Graph class
public class Graph {

    private Map<String, Profile> profiles;
    private Map<String, Set<String>> friendships;

    public Graph() {
        this.profiles = new HashMap<>();
        this.friendships = new HashMap<>();
    }

    public void addProfile(Profile profile) {
        profiles.put(profile.getName(), profile);
        friendships.put(profile.getName(), new HashSet<>());
        saveProfilesToFile("profiles.txt");
    }

    public void removeProfile(Profile profile) {
        profiles.remove(profile.getName());
        friendships.remove(profile.getName());
        for (String friend : profile.getFriends()) {
            friendships.get(friend).remove(profile.getName());
        }
        saveProfilesToFile("profiles.txt");
    }

    public void addFriendship(Profile profile1, Profile profile2) {
        friendships.get(profile1.getName()).add(profile2.getName());
        friendships.get(profile2.getName()).add(profile1.getName());
        saveProfilesToFile("profiles.txt");
    }

    public void removeFriendship(Profile profile1, Profile profile2) {
        friendships.get(profile1.getName()).remove(profile2.getName());
        friendships.get(profile2.getName()).remove(profile1.getName());
        saveProfilesToFile("profiles.txt");
    }

    public Set<String> getFriends(String profileName) {
        return friendships.get(profileName);
    }

    public Map<String, Profile> getProfiles() {
        return this.profiles;
    }

    // Method to save profiles to a TXT file
    public void saveProfilesToFile(String filePath) {
        try (PrintWriter writer = new PrintWriter(filePath)) {
            for (Profile profile : profiles.values()) {
                writer.println(profile.toString());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to load profiles from a TXT file
    public void loadProfilesFromFile(String filePath) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Profile profile = new Profile(line);
                profiles.put(profile.getName(), profile);

                // You need to update friendships here as well
                // For example, by adding the loaded friends to the friendships map
                Set<String> friends = new HashSet<>(profile.getFriends());
                friendships.put(profile.getName(), friends);
            }

            // ... (rest of the method remains the same)
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
